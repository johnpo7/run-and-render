import os
import re
import json

base_dir = "/Users/joppu/Documents/ThePortfolioWeb"
domain = "https://runandrender.com"
default_image = f"{domain}/assets/og-image.jpg"

seo_data = {
    "index.html": {
        "title": "Global Creative & Digital Agency | Run&Render",
        "desc": "Run&Render is a premium global agency specializing in web development, Python automation, AI solutions, and high-end visual design.",
        "url": f"{domain}/",
        "schema_type": "ProfessionalService",
        "schema_name": "Run&Render Agency"
    },
    "services/python-automation.html": {
        "title": "Python Automation & Scripting Services | Run&Render",
        "desc": "Expert Python automation agency. We build custom n8n workflows, Telegram bots, task schedulers, and robust scripts for your business.",
        "url": f"{domain}/services/python-automation.html",
        "schema_type": "Service",
        "schema_name": "Python Automation & Systems"
    },
    "services/web-scraping.html": {
        "title": "Web Scraping Services & Data Extraction | Run&Render",
        "desc": "Professional web scraping and data extraction services. We build real-time scrapers, bypass anti-bot systems, and deliver clean datasets.",
        "url": f"{domain}/services/web-scraping.html",
        "schema_type": "Service",
        "schema_name": "Web Scraping & Data Extraction"
    },
    "services/web-development.html": {
        "title": "Premium Web Development & CMS Solutions | Run&Render",
        "desc": "High-end web development agency. We architect pixel-perfect landing pages, portfolios, and corporate sites with seamless CMS integration.",
        "url": f"{domain}/services/web-development.html",
        "schema_type": "Service",
        "schema_name": "Web Development"
    },
    "services/api-integration.html": {
        "title": "API Integration & Architecture Services | Run&Render",
        "desc": "Expert API integration services connecting REST, GraphQL, and third-party systems. Build seamless, real-time data flows with webhook automation.",
        "url": f"{domain}/services/api-integration.html",
        "schema_type": "Service",
        "schema_name": "API Integration"
    },
    "services/ai-bots.html": {
        "title": "Custom AI Solutions & Chatbot Development | Run&Render",
        "desc": "Deploy intelligent AI systems. We specialize in LLM integrations, custom chatbots, prompt pipelines, and autonomous AI automation.",
        "url": f"{domain}/services/ai-bots.html",
        "schema_type": "Service",
        "schema_name": "AI Solutions & Bots"
    },
    "services/vps-infrastructure.html": {
        "title": "Cloud VPS Hosting & Infrastructure Setup | Run&Render",
        "desc": "Secure cloud infrastructure and server management. We handle Docker deployments, AWS/Oracle cloud, Ubuntu servers, and SSL hardening.",
        "url": f"{domain}/services/vps-infrastructure.html",
        "schema_type": "Service",
        "schema_name": "VPS & Infrastructure"
    },
    "services/graphic-design.html": {
        "title": "Graphic Design & Brand Identity Agency | Run&Render",
        "desc": "Premium graphic design services. We craft striking logo designs, comprehensive brand kits, social media graphics, and agency posters.",
        "url": f"{domain}/services/graphic-design.html",
        "schema_type": "Service",
        "schema_name": "Graphic Design & Branding"
    },
    "services/video-editing.html": {
        "title": "Video Editing & Post-Production Services | Run&Render",
        "desc": "Cinematic video editing and post-production. Elevate your content with professional color grading, motion graphics, and engaging reels.",
        "url": f"{domain}/services/video-editing.html",
        "schema_type": "Service",
        "schema_name": "Video Editing & Post-Production"
    }
}

def generate_head_content(rel_path, data):
    is_root = rel_path == "index.html"
    css_prefix = "" if is_root else "../"
    
    title = data['title']
    desc = data['desc']
    url = data['url']
    
    # Generate JSON-LD Schema
    if data['schema_type'] == "ProfessionalService":
        schema = {
            "@context": "https://schema.org",
            "@type": "ProfessionalService",
            "name": data['schema_name'],
            "url": url,
            "description": desc,
            "image": default_image,
            "address": {
                "@type": "PostalAddress",
                "addressLocality": "New York",
                "addressRegion": "NY",
                "addressCountry": "US"
            }
        }
    else:
        schema = {
            "@context": "https://schema.org",
            "@type": "Service",
            "serviceType": data['schema_name'],
            "provider": {
                "@type": "ProfessionalService",
                "name": "Run&Render"
            },
            "url": url,
            "description": desc
        }
    
    schema_str = json.dumps(schema, indent=2)
    
    head = f"""<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <!-- Primary Meta Tags -->
  <title>{title}</title>
  <meta name="title" content="{title}">
  <meta name="description" content="{desc}">
  <link rel="canonical" href="{url}">

  <!-- Open Graph / Facebook -->
  <meta property="og:type" content="website">
  <meta property="og:url" content="{url}">
  <meta property="og:title" content="{title}">
  <meta property="og:description" content="{desc}">
  <meta property="og:image" content="{default_image}">
  <meta property="og:site_name" content="Run&Render">

  <!-- Twitter -->
  <meta property="twitter:card" content="summary_large_image">
  <meta property="twitter:url" content="{url}">
  <meta property="twitter:title" content="{title}">
  <meta property="twitter:description" content="{desc}">
  <meta property="twitter:image" content="{default_image}">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="{css_prefix}css/themes.css">
  <link rel="stylesheet" href="{css_prefix}css/styles.css">
  <link rel="stylesheet" href="{css_prefix}css/animations.css">
  <link rel="stylesheet" href="{css_prefix}css/responsive.css">

  <!-- JSON-LD Structured Data -->
  <script type="application/ld+json">
{schema_str}
  </script>
</head>"""
    return head

def process_file(file_path, rel_path, data):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Replace <head>...</head>
    # Using regex to find the head block
    new_head = generate_head_content(rel_path, data)
    content = re.sub(r'<head>.*?</head>', new_head, content, flags=re.DOTALL)
    
    # Update SVGs for accessibility
    # Add role="img" and aria-label to svg tags that don't have them
    # For SVGs inside service cards, we want to add an alt/aria-label based on the adjacent h3 text if possible
    # A simpler robust way via regex:
    
    # First, let's find all svgs. 
    # If an svg doesn't have an aria-label or role, let's add role="img" and aria-hidden="true".
    # Wait, the prompt said: "Ensure every single <img> or icon element contains a descriptive, keyword-conscious alt attribute."
    # So we should add aria-label and role="img" to the SVGs.
    # To do this safely, we can write a small replacer.
    
    def svg_replacer(match):
        svg_tag = match.group(0)
        # We need to find the title context if possible, but regex is tricky.
        # Let's just inject role="img" aria-label="Service Icon" into the svg opening tag
        if 'role="img"' not in svg_tag:
            return svg_tag.replace('<svg ', '<svg role="img" aria-label="Decorative Service Icon" ')
        return svg_tag

    # Wait, the user wants a "descriptive, keyword-conscious alt attribute".
    # Let's use BeautifulSoup to accurately pair the SVG with the adjacent <h3> text.
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
print("Applying SEO and schema updates...")
for rel_path, data in seo_data.items():
    file_path = os.path.join(base_dir, rel_path)
    if os.path.exists(file_path):
        process_file(file_path, rel_path, data)
print("Finished basic SEO. Next we will use beautifulsoup to accurately set the SVG aria-labels.")

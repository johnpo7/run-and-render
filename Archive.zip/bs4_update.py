import os
from bs4 import BeautifulSoup

base_dir = "/Users/joppu/Documents/ThePortfolioWeb"
files_to_process = [
    "index.html",
    "services/python-automation.html",
    "services/web-scraping.html",
    "services/web-development.html",
    "services/api-integration.html",
    "services/ai-bots.html",
    "services/vps-infrastructure.html",
    "services/graphic-design.html",
    "services/video-editing.html"
]

for rel_path in files_to_process:
    file_path = os.path.join(base_dir, rel_path)
    if not os.path.exists(file_path):
        continue
        
    with open(file_path, 'r', encoding='utf-8') as f:
        html_content = f.read()
        
    soup = BeautifulSoup(html_content, 'html.parser')
    
    # Process all svgs
    for svg in soup.find_all('svg'):
        # Add role img
        svg['role'] = 'img'
        
        # Try to find a nearby h3 to use as alt text
        parent = svg.parent
        h3 = parent.find('h3')
        if not h3 and parent.parent:
            h3 = parent.parent.find('h3')
            
        if h3:
            label = f"Icon for {h3.get_text(strip=True)}"
            svg['aria-label'] = label
        else:
            # Fallback for svgs without nearby h3 (like hamburger, checkmarks)
            if 'hamburger' in (svg.get('id', '') or ''):
                svg['aria-label'] = 'Hamburger Menu Icon'
            else:
                svg['aria-label'] = 'Decorative Icon'

    # Ensure valid string conversion back to HTML
    new_html = str(soup)
    
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(new_html)

print("SVG accessibility updates complete.")

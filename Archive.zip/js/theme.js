/* ═══════════════════════════════════════
   Run&Render — Theme Controller
   Light/Dark Mode Toggle + Persistence
   ═══════════════════════════════════════ */

(function () {
  'use strict';

  const body = document.body;
  const savedTheme = localStorage.getItem('theme') || 'dark';

  // Apply saved theme immediately (before DOMContentLoaded) to prevent flash
  body.setAttribute('data-theme', savedTheme);

  document.addEventListener('DOMContentLoaded', () => {
    const themeToggle = document.getElementById('theme-toggle');
    if (!themeToggle) return;

    updateIcon(savedTheme);

    themeToggle.addEventListener('click', () => {
      const current = body.getAttribute('data-theme');
      const target = current === 'dark' ? 'light' : 'dark';

      body.setAttribute('data-theme', target);
      localStorage.setItem('theme', target);
      updateIcon(target);
    });

    function updateIcon(theme) {
      // Sun icon when dark (click to go light), Moon when light (click to go dark)
      themeToggle.innerHTML = theme === 'dark' ? '&#9728;' : '&#9790;';
      themeToggle.setAttribute('aria-label', theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode');
    }
  });
})();

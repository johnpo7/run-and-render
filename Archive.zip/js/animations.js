/* ═══════════════════════════════════════
   Run&Render — Animation Controller
   IntersectionObserver Scroll Reveals,
   Parallax, Magnetic Cards
   ═══════════════════════════════════════ */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', () => {

    // ─── IntersectionObserver: Scroll Reveals ───
    const revealElements = document.querySelectorAll('.reveal');
    const revealOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const revealOnScroll = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
          observer.unobserve(entry.target);
        }
      });
    }, revealOptions);

    revealElements.forEach(el => revealOnScroll.observe(el));

    // ─── Parallax Effect ───
    const parallaxImages = document.querySelectorAll('.parallax-img');

    if (parallaxImages.length > 0) {
      window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        parallaxImages.forEach(img => {
          img.style.transform = `translateY(${scrolled * 0.1 - 10}%)`;
        });
      }, { passive: true });
    }

    // ─── Magnetic Card Hover (desktop only) ───
    const serviceCards = document.querySelectorAll('.service-card');
    const isTouchDevice = window.matchMedia('(hover: none)').matches;

    if (!isTouchDevice && serviceCards.length > 0) {
      serviceCards.forEach(card => {
        card.addEventListener('mousemove', (e) => {
          const rect = card.getBoundingClientRect();
          const x = e.clientX - rect.left;
          const y = e.clientY - rect.top;
          const centerX = rect.width / 2;
          const centerY = rect.height / 2;
          const rotateX = (y - centerY) / 20;
          const rotateY = (centerX - x) / 20;

          card.style.transform = `translateY(-8px) perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
        });

        card.addEventListener('mouseleave', () => {
          card.style.transform = '';
        });
      });
    }

    // ─── Sticky Navbar Shrink ───
    const navbar = document.getElementById('navbar');
    if (navbar) {
      window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
          navbar.classList.add('scrolled');
        } else {
          navbar.classList.remove('scrolled');
        }
      }, { passive: true });
    }

  });
})();

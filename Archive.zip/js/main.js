/* ═══════════════════════════════════════
   Run&Render — Main Controller
   Hamburger Menu, URL Param Routing,
   Contact Form Pre-selection
   ═══════════════════════════════════════ */

(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', () => {

    // ─── Mobile Hamburger Menu ───
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('nav-links');

    if (hamburger && navLinks) {
      hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('active');
        const isOpen = navLinks.classList.contains('active');
        hamburger.innerHTML = isOpen ? '&#10005;' : '&#9776;';
        hamburger.setAttribute('aria-expanded', isOpen);
        // Prevent body scroll when menu is open
        document.body.style.overflow = isOpen ? 'hidden' : '';
      });

      // Close menu when a nav link is clicked (for in-page anchors)
      navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
          navLinks.classList.remove('active');
          hamburger.innerHTML = '&#9776;';
          hamburger.setAttribute('aria-expanded', 'false');
          document.body.style.overflow = '';
        });
      });
    }

    // ─── URL Parameter → Contact Form Pre-selection ───
    // Service pages link to: ../index.html?service=web-scraping#contact
    // This reads the ?service= param and pre-selects the dropdown
    const serviceDropdown = document.getElementById('service-select');

    if (serviceDropdown) {
      const params = new URLSearchParams(window.location.search);
      const serviceParam = params.get('service');

      if (serviceParam) {
        const option = serviceDropdown.querySelector(`option[value="${serviceParam}"]`);
        if (option) {
          serviceDropdown.value = serviceParam;
        }
      }
    }

  });
})();
